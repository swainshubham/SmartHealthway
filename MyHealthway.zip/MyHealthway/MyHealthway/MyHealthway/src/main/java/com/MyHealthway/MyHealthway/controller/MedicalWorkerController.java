package com.MyHealthway.MyHealthway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;

import com.MyHealthway.MyHealthway.model.MedicalWorker;
import com.MyHealthway.MyHealthway.service.MedicalWorkerService;


@Controller
public class MedicalWorkerController {

    @Autowired
    private MedicalWorkerService medicalWorkerService;

    @GetMapping("/worker/login")
    public String showLoginPage() {
        return "medical-worker-login"; // Corresponds to medical-worker-login.html
    }

    @PostMapping("/medical-worker/login")
    public String login(@RequestParam("email") String email, 
                        @RequestParam("password") String password, 
                        Model model) {
        MedicalWorker worker = medicalWorkerService.login(email, password);
        if (worker != null) {
            model.addAttribute("medicalWorker", worker);
            return "medical-worker-dashboard"; // Corresponds to medical-worker-dashboard.html
        } else {
            model.addAttribute("error", "Invalid email or password.");
            return "medical-worker-login";
        }
    }
}
