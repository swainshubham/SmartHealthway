package com.MyHealthway.MyHealthway.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

import com.MyHealthway.MyHealthway.model.HealthReport;

public interface HealthReportRepository extends JpaRepository<HealthReport, Long> {
    List<HealthReport> findByPatientHealthId(String patientHealthId);
}