package com.MyHealthway.MyHealthway.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MyHealthway.MyHealthway.Repository.HealthReportRepository;
import com.MyHealthway.MyHealthway.Repository.MedicalWorkerRepository;
import com.MyHealthway.MyHealthway.model.HealthReport;
import com.MyHealthway.MyHealthway.model.MedicalWorker;

@Service
public class MedicalWorkerService {
    
    @Autowired
    private MedicalWorkerRepository medicalWorkerRepository;
    @Autowired
    private HealthReportRepository healthReportRepository;

    public MedicalWorker login(String email, String password) {
        // Assuming the email and password are being passed to the repository for authentication
        return medicalWorkerRepository.findByEmailAndPassword(email, password);
    }

    public void uploadReportText(Long reportId, Long workerId, String reportText) {
        Optional<HealthReport> reportOptional = healthReportRepository.findById(reportId);
        if (reportOptional.isPresent()) {
            HealthReport report = reportOptional.get();
            report.setReportText(reportText); // Set the report text
            report.setMedicalWorkerId(workerId); // Set the worker ID
            healthReportRepository.save(report); // Save the changes
        } else {
            throw new RuntimeException("Report not found with ID: " + reportId);
        }
    }
}
