package com.MyHealthway.MyHealthway.Repository;

import com.MyHealthway.MyHealthway.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PatientRepository extends JpaRepository<Patient, Integer> {
    // Method to find a patient by health ID
    Patient findByHealthId(String healthId);
    Optional<Patient> findByEmail(String email);
    // Method to verify login credentials
    Optional<Patient> findByHealthIdAndPassword(String healthId, String password);
}
