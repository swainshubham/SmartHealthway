package com.MyHealthway.MyHealthway.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.MyHealthway.MyHealthway.model.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
     /**
     * Check if a specific time slot is booked for a doctor on a given date.
     */
    boolean existsByDoctorIdAndAppointmentDateAndTimeSlot(Long doctorId, LocalDate appointmentDate, LocalTime timeSlot);

    /**
     * Find all appointments for a specific patient based on their health ID.
     */
    List<Appointment> findByPatientHealthId(String patientHealthId);

    /**
     * Find all appointments for a specific doctor on a specific date.
     */
    List<Appointment> findByDoctorIdAndAppointmentDate(Long doctorId, LocalDate appointmentDate);

    /**
     * Get all booked time slots for a specific doctor on a specific date.
     */
    @Query("SELECT a.timeSlot FROM Appointment a WHERE a.doctorId = :doctorId AND a.appointmentDate = :appointmentDate")
    List<String> getBookedTimeSlots(Long doctorId, LocalDate appointmentDate);

    List<Appointment> findByDoctorId(Long doctorId);
    
}
