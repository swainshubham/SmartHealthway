package com.MyHealthway.MyHealthway.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.MyHealthway.MyHealthway.Repository.PatientRepository;
import com.MyHealthway.MyHealthway.model.HealthReport;
import com.MyHealthway.MyHealthway.model.Patient;
import com.MyHealthway.MyHealthway.service.HealthReportService;

@Controller
@RequestMapping("/patient")
public class PatientController {

    @Autowired
    private PatientRepository patientRepository;

    // Display login page
    @GetMapping("/login")
    public String showLoginPage() {
        return "patientlogin";
    }

    // Handle login form submission
    @PostMapping("/login")
    public String handleLogin(
            @RequestParam("healthId") String healthId,
            @RequestParam("password") String password,
            Model model) {
        // Fetch patient by health ID
        Patient patient = patientRepository.findByHealthId(healthId);

        // Validate credentials
        if (patient != null && patient.getPassword().equals(password)) {
            model.addAttribute("patient", patient);
            return "patient-dashboard"; // Redirect to dashboard
        } else {
            model.addAttribute("error", "Invalid Health ID or Password");
            return "patientlogin"; // Redirect back to login with error
        }
    }

    // Dashboard page
    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        // Ensure the patient is already authenticated before showing the dashboard
        if (!model.containsAttribute("patient")) {
            return "redirect:/patient/login"; // Redirect to login if not authenticated
        }
        return "patient-dashboard";
    }

    // Logout
    @GetMapping("/logout")
    public String logout() {
        return "redirect:/patient/login"; // Clear session and redirect to login
    }
    @Autowired
    private HealthReportService healthReportService;

    @GetMapping("/reports1")
    public String viewReports(@RequestParam("healthId") String healthId, Model model) {
        // Fetch reports based on healthId
        List<HealthReport> reports = healthReportService.findReportsByPatientHealthId(healthId);

        // Add the reports and healthId to the model
        model.addAttribute("reports", reports);
        model.addAttribute("healthId", healthId);

        // Return the name of the HTML page that will display the reports
        return "view-reports"; // This corresponds to the "view-reports.html" page
    }  
      
}
