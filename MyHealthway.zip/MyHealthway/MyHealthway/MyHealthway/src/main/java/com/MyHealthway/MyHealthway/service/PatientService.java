package com.MyHealthway.MyHealthway.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MyHealthway.MyHealthway.Repository.PatientRepository;
import com.MyHealthway.MyHealthway.model.Patient;

@Service  // This annotation marks the class as a Spring Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    
    public Patient signUpPatient(String name, String email, String password) {
        // Check if email already exists
        if (patientRepository.findByEmail(email).isPresent()) {
            throw new RuntimeException("Email already exists!");
        }

        // Generate a unique health ID
        String healthId = generateHealthId();

        // Create a new Patient object
        Patient patient = new Patient();
        patient.setHealthId(healthId);
        patient.setName(name);
        patient.setEmail(email);
        patient.setPassword(password);

        // Save the patient to the database
        return patientRepository.save(patient);
    }

    // Generate an 8-character alphanumeric health ID
    private String generateHealthId() {
        String alphanumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder healthId = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 8; i++) {
            healthId.append(alphanumeric.charAt(random.nextInt(alphanumeric.length())));
        }

        return healthId.toString();
    }
    
}