package com.MyHealthway.MyHealthway.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MyHealthway.MyHealthway.Repository.DoctorRepository;
import com.MyHealthway.MyHealthway.model.Doctor;

@Service
public class DoctorService {
    @Autowired
    private DoctorRepository doctorRepository;

    public Doctor login(String email, String password) {
        Doctor doctor = doctorRepository.findByEmail(email);
        if (doctor != null && doctor.getPassword().equals(password)) {
            return doctor;
        }
        return null;
    }


    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }
}
