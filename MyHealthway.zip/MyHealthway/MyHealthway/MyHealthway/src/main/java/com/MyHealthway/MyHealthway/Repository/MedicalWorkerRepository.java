package com.MyHealthway.MyHealthway.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.MyHealthway.MyHealthway.model.MedicalWorker;

@Repository
public interface MedicalWorkerRepository extends JpaRepository<MedicalWorker, Long> {
    MedicalWorker findByEmailAndPassword(String email, String password);
}
