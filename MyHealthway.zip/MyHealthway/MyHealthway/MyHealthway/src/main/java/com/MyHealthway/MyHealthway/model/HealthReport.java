package com.MyHealthway.MyHealthway.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "health_reports")
public class HealthReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "patient_health_id", nullable = false)
    private String patientHealthId;

    @Column(name = "doctor_id", nullable = false)
    private Long doctorId;

    @Column(name = "report_text")
    private String reportText;

    @Column(name = "medicine")
    private String medicine;

    @Column(name = "test_type")
    private String testType;

    @Column(name = "medical_worker_id")
    private Long medicalWorkerId;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPatientHealthId() {
        return patientHealthId;
    }

    public void setPatientHealthId(String patientHealthId) {
        this.patientHealthId = patientHealthId;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public String getReportText() {
        return reportText;
    }

    public void setReportText(String reportText) {
        this.reportText = reportText;
    }

    public String getMedicine() {
        return medicine;
    }

    public void setMedicine(String medicine) {
        this.medicine = medicine;
    }

    public String getTestType() {
        return testType;
    }

    public void setTestType(String testType) {
        this.testType = testType;
    }

    public Long getMedicalWorkerId() {
        return medicalWorkerId;
    }

    public void setMedicalWorkerId(Long medicalWorkerId) {
        this.medicalWorkerId = medicalWorkerId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}