package com.MyHealthway.MyHealthway.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "appointments")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Auto-incremented primary key

    @Column(name = "patient_health_id", nullable = false, length = 50)
    private String patientHealthId; // Health ID of the patient

    @Column(name = "doctor_id", nullable = false)
    private Long doctorId; // ID of the doctor

    @Column(name = "appointment_date", nullable = false)
    private LocalDate appointmentDate; // Date of the appointment

    @Column(name = "time_slot", nullable = false)
    private LocalTime timeSlot; // 30-minute time slot for the appointment

    @Column(name = "status", nullable = false, length = 20)
    private String status; // Status of the appointment (e.g., "booked", "cancelled")

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPatientHealthId() {
        return patientHealthId;
    }

    public void setPatientHealthId(String patientHealthId) {
        this.patientHealthId = patientHealthId;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(LocalDate appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public LocalTime getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(LocalTime timeSlot) {
        this.timeSlot = timeSlot;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
