package com.MyHealthway.MyHealthway.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.MyHealthway.MyHealthway.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, String> {
}