package com.MyHealthway.MyHealthway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan(basePackages = "com.MyHealthway.MyHealthway.service")
@ComponentScan(basePackages = "com.MyHealthway.MyHealthway.Repository")
@ComponentScan(basePackages = "com.MyHealthway.MyHealthway.model")
@ComponentScan(basePackages = { "com.MyHealthway.MyHealthway.controller" })
@SpringBootApplication
public class MyHealthwayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyHealthwayApplication.class, args);
		System.out.println("MyHealthWay....");
	}

}
