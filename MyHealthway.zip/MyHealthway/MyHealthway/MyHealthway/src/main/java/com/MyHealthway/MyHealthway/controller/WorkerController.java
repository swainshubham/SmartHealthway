package com.MyHealthway.MyHealthway.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.MyHealthway.MyHealthway.model.HealthReport;
import com.MyHealthway.MyHealthway.service.HealthReportService;

@Controller
@RequestMapping("/medical-worker")
public class WorkerController {
    @Autowired
    private HealthReportService healthReportService;

    // Display upload-test-report page
    @GetMapping("/upload-report")
    public String getUploadReportPage(@RequestParam("workerId") Long workerId, Model model) {
        model.addAttribute("workerId", workerId); // Pass workerId to the frontend
        return "upload-test-report"; // Renders the upload-test-report.html
    }

    // Search Health Reports by Health ID
    @GetMapping("/search-health-reports")
    @ResponseBody
    public List<HealthReport> searchHealthReports(@RequestParam("healthId") String healthId) {
        return healthReportService.findReportsByPatientHealthId(healthId);
    }

    // Upload Report Text
    @PostMapping("/upload-report-text")
    @ResponseBody
    public String uploadReportText(
            @RequestParam("reportId") Long reportId,
            @RequestParam("workerId") Long workerId,
            @RequestParam("reportText") String reportText) {

        boolean isUpdated = healthReportService.updateReportText(reportId, workerId, reportText);
        return isUpdated ? "success" : "error";
    }

}
