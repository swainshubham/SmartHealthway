package com.MyHealthway.MyHealthway.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

import com.MyHealthway.MyHealthway.Repository.HealthReportRepository;
import com.MyHealthway.MyHealthway.model.HealthReport;

@Service
public class HealthReportService {

    @Autowired
    private HealthReportRepository healthReportRepository;

    public List<HealthReport> findReportsByPatientHealthId(String patientHealthId) {
        return healthReportRepository.findByPatientHealthId(patientHealthId);
    }

    

    public void assignMedicine(Long reportId, String medicine) {
        HealthReport report = healthReportRepository.findById(reportId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid Report ID"));
        report.setMedicine(medicine);
        healthReportRepository.save(report);
    }


    public void saveHealthReport(Long doctorId, String patientHealthId, String medicine, String testType) {
        HealthReport healthReport = new HealthReport();
        healthReport.setDoctorId(doctorId);
        healthReport.setPatientHealthId(patientHealthId);
        healthReport.setMedicine(medicine);
        healthReport.setReportText("Test Type: " + testType); // You can store testType in the report text or add a column for it
        healthReport.setCreatedAt(LocalDateTime.now());

        healthReportRepository.save(healthReport);
    }

    public void saveHealthReport(HealthReport healthReport) {
        healthReportRepository.save(healthReport);
    }

    public boolean updateReportText(Long reportId, Long workerId, String reportText) {
        try {
            HealthReport report = healthReportRepository.findById(reportId).orElseThrow(() -> new IllegalArgumentException("Invalid report ID"));
            report.setReportText(reportText);
            report.setMedicalWorkerId(workerId);
            healthReportRepository.save(report);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<HealthReport> getAllReports() {
        return healthReportRepository.findAll();
    }
    
}