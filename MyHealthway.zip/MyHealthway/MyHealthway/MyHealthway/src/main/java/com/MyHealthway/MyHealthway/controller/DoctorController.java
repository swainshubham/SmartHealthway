package com.MyHealthway.MyHealthway.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.MyHealthway.MyHealthway.model.Appointment;
import com.MyHealthway.MyHealthway.model.Doctor;
import com.MyHealthway.MyHealthway.model.HealthReport;
import com.MyHealthway.MyHealthway.service.AppointmentService;
import com.MyHealthway.MyHealthway.service.DoctorService;
import com.MyHealthway.MyHealthway.service.HealthReportService;

@Controller
public class DoctorController {
    @Autowired
    private DoctorService doctorService;
    @Autowired
    private HealthReportService healthReportService;

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/login/doctor")
    public String showLoginPage() {
        return "Doctorlogin";
    }

    @GetMapping("/lg")
    public String showIndexPage() {
        return "/index";
    }

    @PostMapping("/doctor/login")
    public String login(@RequestParam String email, @RequestParam String password, Model model) {
        Doctor doctor = doctorService.login(email, password);
        if (doctor != null) {
            model.addAttribute("doctor", doctor);
            return "doctor-dashboard";
        } else {
            model.addAttribute("error", "Invalid email or password.");
            return "Doctorlogin";
        }
    }

    @GetMapping("/assign-test")
public String assignTestPage() {
    return "assign-test"; // The name of the HTML page to render
}

@GetMapping("/assign-test/search")
@ResponseBody
public List<HealthReport> searchHealthReports(@RequestParam("patientHealthId") String patientHealthId) {
    return healthReportService.findReportsByPatientHealthId(patientHealthId);
}

//assign medicine and test type
@GetMapping("/assign-medicine1")
public String showAssignForm(@RequestParam("doctorId") Long doctorId, Model model) {
    model.addAttribute("doctorId", doctorId);
    return "assignMedicineForm"; // Thymeleaf view name
}

@PostMapping("/assign-report")
public String assignReport(@RequestParam("doctorId") Long doctorId,
                           @RequestParam("patientHealthId") String patientHealthId,
                           @RequestParam("medicine") String medicine,
                           @RequestParam("testType") String testType) {
    // Create a new HealthReport object and populate it
    HealthReport healthReport = new HealthReport();
    healthReport.setDoctorId(doctorId);
    healthReport.setPatientHealthId(patientHealthId);
    healthReport.setMedicine(medicine.isEmpty() ? null : medicine); // Medicine is optional, can be null
    healthReport.setTestType(testType);

    // Save the health report in the database
    healthReportService.saveHealthReport(healthReport);

    // Redirect back to the doctor dashboard
    return "redirect:/";
}

@PostMapping("/assign-test/assign-medicine")
    public ResponseEntity<String> assignMedicine(@RequestBody Map<String, Object> requestBody) {
        try {
            Long reportId = Long.valueOf(requestBody.get("reportId").toString());
            String medicine = requestBody.get("medicine").toString();

            // Use the service to assign the medicine
            healthReportService.assignMedicine(reportId, medicine);

            return ResponseEntity.ok("Medicine assigned successfully!");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error assigning medicine: " + e.getMessage());
        }
    }
     

    @GetMapping("/doctor/appointments")
    public String showAppointments(@RequestParam("doctorId") Long doctorId, Model model) {
        // Fetch all appointments for the given doctorId
        List<Appointment> appointments = appointmentService.getAppointmentsByDoctorId(doctorId);

        // Add the appointments and doctorId to the model
        model.addAttribute("appointments", appointments);
        model.addAttribute("doctorId", doctorId);

        // Return the view to display the appointments
        return "doctor-appointments"; // Corresponds to doctor-appointments.html
    }

}
