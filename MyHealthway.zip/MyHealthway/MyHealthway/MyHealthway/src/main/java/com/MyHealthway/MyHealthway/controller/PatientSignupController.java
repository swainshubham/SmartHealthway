package com.MyHealthway.MyHealthway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import com.MyHealthway.MyHealthway.model.Patient;
import com.MyHealthway.MyHealthway.service.PatientService;

@Controller
public class PatientSignupController {

    @Autowired
    private PatientService patientService;

    // Show signup form
    @GetMapping("/signup")
    public String showSignupPage() {
        return "patient-signup";
    }

   
    @PostMapping("/patient-signup")
    public String signUpPatient(@ModelAttribute("patient") Patient patient, Model model) {
        try {
            // Call the service to sign up the patient
            Patient savedPatient = patientService.signUpPatient(
                patient.getName(),
                patient.getEmail(),
                patient.getPassword()
            );

            // Add the healthId to the model so it can be displayed on the same page
            model.addAttribute("healthId", savedPatient.getHealthId());
            model.addAttribute("signupSuccess", true); // Flag to trigger popup
        } catch (RuntimeException e) {
            // Add error message to model if an issue occurs
            model.addAttribute("error", e.getMessage());
        }
        return "patient-signup"; // Stay on the same signup page
    }
    
}