package com.MyHealthway.MyHealthway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.MyHealthway.MyHealthway.service.AdminService;
import com.MyHealthway.MyHealthway.service.HealthReportService;

@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private HealthReportService healthReportService;

    // Display admin signup/login page
    @GetMapping("/login/admin")
    public String showAdminLoginPage() {
        return "admin-login";
    }

    // Handle admin login verification
    @PostMapping("/admin/verify")
    public String verifyAdminLogin(@RequestParam("id") String id, 
                                   @RequestParam("password") String password, Model model) {
        boolean isAuthenticated = adminService.verifyAdmin(id, password);

        if (isAuthenticated) {
            // Redirect to the report viewing page
            model.addAttribute("reports", healthReportService.getAllReports());
            return "health-report-table"; // This is the HTML page to display reports
        } else {
            // If authentication fails, redirect back to login page with error
            model.addAttribute("error", "Invalid ID or password!");
            return "admin-login";
        }
    }
    @GetMapping("/contact")
    public String showContactPage(Model model) {
        return "contact-us"; // Return the contact-us template
    }
}
