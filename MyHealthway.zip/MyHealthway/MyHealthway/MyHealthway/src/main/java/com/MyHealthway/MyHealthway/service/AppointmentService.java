package com.MyHealthway.MyHealthway.service;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MyHealthway.MyHealthway.Repository.AppointmentRepository;
import com.MyHealthway.MyHealthway.model.Appointment;
@Service
public class AppointmentService {
     @Autowired
    private AppointmentRepository appointmentRepository;

    // List of all time slots (30-minute intervals between 9 AM and 4 PM)
    private final List<String> timeSlots = generateTimeSlots();

    /**
     * Get available time slots for a specific doctor on a specific date.
     */
    public List<String> getAvailableTimeSlots(Long doctorId, LocalDate appointmentDate) {
        List<String> bookedSlots = appointmentRepository.getBookedTimeSlots(doctorId, appointmentDate);
        List<String> availableSlots = new ArrayList<>(timeSlots);

        // Remove booked slots from the available list
        availableSlots.removeAll(bookedSlots);
        return availableSlots;
    }

    /**
     * Book an appointment.
     */
    public boolean bookAppointment(String patientHealthId, Long doctorId, LocalDate appointmentDate, LocalTime timeSlot) {
        // Check if the time slot is already booked
        if (appointmentRepository.existsByDoctorIdAndAppointmentDateAndTimeSlot(doctorId, appointmentDate, timeSlot)) {
            return false; // Time slot already booked
        }

        // Create and save the appointment
        Appointment appointment = new Appointment();
        appointment.setPatientHealthId(patientHealthId);
        appointment.setDoctorId(doctorId);
        appointment.setAppointmentDate(appointmentDate);
        appointment.setTimeSlot(timeSlot);
        appointment.setStatus("booked");

        appointmentRepository.save(appointment);
        return true;
    }

    /**
     * Generate time slots for the day (9:00 AM - 4:00 PM, 30-minute intervals).
     */
    private static List<String> generateTimeSlots() {
        List<String> slots = new ArrayList<>();
        LocalTime start = LocalTime.of(9, 0);
        LocalTime end = LocalTime.of(16, 0);

        while (!start.isAfter(end)) {
            slots.add(start.toString()); // Format: HH:mm
            start = start.plusMinutes(30);
        }
        return slots;
    } 
     
    public List<Appointment> getAppointmentsByDoctorId(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

   
}
