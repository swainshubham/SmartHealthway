package com.MyHealthway.MyHealthway.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MyHealthway.MyHealthway.Repository.AdminRepository;
import com.MyHealthway.MyHealthway.model.Admin;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public boolean verifyAdmin(String id, String password) {
        Optional<Admin> admin = adminRepository.findById(id);

        // Check if admin exists and password matches
        return admin.isPresent() && admin.get().getPassword().equals(password);
    }
}