package com.MyHealthway.MyHealthway.controller;

import java.time.LocalDate;
import java.time.LocalTime;  // Import LocalTime
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.MyHealthway.MyHealthway.service.AppointmentService;
import com.MyHealthway.MyHealthway.service.DoctorService;

@Controller
@RequestMapping("/patient")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private DoctorService doctorService;

    /**
     * Display appointment booking page.
     */
    @GetMapping("/appointments")
    public String showAppointmentPage(@RequestParam("healthId") String healthId, Model model) {
        model.addAttribute("healthId", healthId); // Pass patient health ID
        model.addAttribute("doctors", doctorService.getAllDoctors()); // Fetch all doctors for dropdown
        return "book-appointment"; // Render the booking page
    }

    /**
     * Fetch available time slots for a specific doctor and date.
     */
    @GetMapping("/appointments/available-slots")
    @ResponseBody
    public List<String> getAvailableSlots(@RequestParam Long doctorId, @RequestParam String appointmentDate) {
        return appointmentService.getAvailableTimeSlots(doctorId, LocalDate.parse(appointmentDate));
    }

    /**
     * Book an appointment.
     */
    @PostMapping("/appointments")
    @ResponseBody
    public String bookAppointment(
            @RequestParam String healthId,
            @RequestParam Long doctorId,
            @RequestParam String appointmentDate,
            @RequestParam String timeSlot) {
        
        // Parse timeSlot string into LocalTime
        LocalTime parsedTimeSlot = LocalTime.parse(timeSlot);
        
        // Book the appointment with LocalTime
        boolean success = appointmentService.bookAppointment(healthId, doctorId, LocalDate.parse(appointmentDate), parsedTimeSlot);
        
        return success ? "Appointment booked successfully!" : "Time slot already booked.";
    }

   
}
