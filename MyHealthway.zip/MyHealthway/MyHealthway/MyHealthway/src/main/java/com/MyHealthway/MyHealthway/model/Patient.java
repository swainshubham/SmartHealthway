package com.MyHealthway.MyHealthway.model;

import jakarta.persistence.*;

@Entity
@Table(name = "patients") // Maps to the `patient` table in the database
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment for the primary key
    private Integer id;

    @Column(name = "health_id", nullable = false, unique = true) // Unique and required
    private String healthId;

    @Column(name = "name", nullable = false) // Required
    private String name;

    @Column(name = "email", nullable = false, unique = true) // Unique and required
    private String email;

    @Column(name = "password", nullable = false) // Required
    private String password;
    public Patient() {
    }

    public Patient(String name, String email, String password, String healthId) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.healthId = healthId;
    }

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHealthId() {
        return healthId;
    }

    public void setHealthId(String healthId) {
        this.healthId = healthId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
