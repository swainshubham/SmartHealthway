package com.MyHealthway.MyHealthway;

import org.springframework.boot.SpringApplication;

public class TestMyHealthwayApplication {

	public static void main(String[] args) {
		SpringApplication.from(MyHealthwayApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
